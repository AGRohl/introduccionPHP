<?php
/* 
 * Es un archivo genérico de configuración.
 */
$host="";
$user="";
$pass="";
$database="";

?>
