<?php
/* 
 * Es un archivo genérico de configuración.
 */
$host="localhost";
$user="ausias";
$pass="ausias";
$database="neptuno";

?>
